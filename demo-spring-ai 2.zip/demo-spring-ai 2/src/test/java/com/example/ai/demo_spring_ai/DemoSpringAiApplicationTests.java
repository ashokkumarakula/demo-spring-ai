package com.example.ai.demo_spring_ai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSpringAiApplicationTests {

	@Test
	void contextLoads() {
	}

}
