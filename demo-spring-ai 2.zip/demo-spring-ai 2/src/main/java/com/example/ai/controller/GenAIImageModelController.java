package com.example.ai.controller;


import org.springframework.ai.image.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GenAIImageModelController {

    private final ImageModel imageModel;

    @Autowired
    public GenAIImageModelController(ImageModel imageModel) {
        this.imageModel = imageModel;
    }

    @GetMapping("/imagegen")
    public String imageGen(@RequestBody com.example.ai.request.imageGenRequest imageGenRequest) {

        ImageOptions options = ImageOptionsBuilder.builder()
                .withModel("dall-e-3")
                .build();
        ImagePrompt imagePrompt = new ImagePrompt(imageGenRequest.prompt(), options);

        System.out.println("ImageModel - STARTED!!! - " + imageGenRequest.prompt());
        ImageResponse response = imageModel.call(imagePrompt);
        System.out.println("ImageModel - DONE!!! " + response);

        return "redirect:" + response.getResult().getOutput().getUrl();
    }
}
