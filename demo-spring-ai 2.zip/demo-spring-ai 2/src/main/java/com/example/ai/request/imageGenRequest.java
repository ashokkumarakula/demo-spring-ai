package com.example.ai.request;

public record imageGenRequest(String prompt) {
}
